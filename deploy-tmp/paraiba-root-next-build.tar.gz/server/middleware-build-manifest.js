globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Eq3pJFferK9MSgVHzboVS/_buildManifest.js",
    "static/Eq3pJFferK9MSgVHzboVS/_ssgManifest.js",
    "static/Eq3pJFferK9MSgVHzboVS/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/43qi2ef0_-07u.js",
    "static/chunks/3h27sg9yi34-x.js",
    "static/chunks/4561u0v7ysn3r.js",
    "static/chunks/0eo1cde-rr3bs.js",
    "static/chunks/turbopack-41bxbyj8yhc2r.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
