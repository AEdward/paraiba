module.exports=[37047,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_legal_privacy_page_actions_11c5ogd.js.map