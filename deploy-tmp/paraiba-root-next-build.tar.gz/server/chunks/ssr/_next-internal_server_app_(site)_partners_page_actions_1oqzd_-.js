module.exports=[31925,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_partners_page_actions_1oqzd_-.js.map