module.exports=[26155,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_legal_cookies_page_actions_004ur-z.js.map