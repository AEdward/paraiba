module.exports=[18210,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_team_page_actions_13rb7e2.js.map