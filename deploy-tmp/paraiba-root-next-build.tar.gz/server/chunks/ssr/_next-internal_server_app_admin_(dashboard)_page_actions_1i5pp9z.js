module.exports=[94436,a=>{"use strict";var b=a.i(3171);a.s([],69445),a.i(69445),a.s(["0095ac9cd4abea72dc68d3fc1860812a8cd4cff00c",()=>b.logout],94436)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_page_actions_1i5pp9z.js.map