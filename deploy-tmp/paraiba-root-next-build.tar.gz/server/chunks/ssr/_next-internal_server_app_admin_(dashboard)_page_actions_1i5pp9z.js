module.exports=[94436,a=>{"use strict";var b=a.i(3171);a.s([],69445),a.i(69445),a.s(["004b39a86c76899ecef066e2ab7b6aae157aa75b29",()=>b.logout],94436)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_page_actions_1i5pp9z.js.map