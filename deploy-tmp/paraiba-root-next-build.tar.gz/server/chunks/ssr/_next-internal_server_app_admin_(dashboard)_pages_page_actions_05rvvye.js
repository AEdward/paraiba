module.exports=[34462,a=>{"use strict";var b=a.i(3171);a.s([],36618),a.i(36618),a.s(["00fabf12110faa8d0277a79792856241444883afc8",()=>b.logout],34462)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_pages_page_actions_05rvvye.js.map