module.exports=[34462,a=>{"use strict";var b=a.i(3171);a.s([],36618),a.i(36618),a.s(["008b598ed1f6881bd19abc51f380c89f8c676d5bcd",()=>b.logout],34462)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_pages_page_actions_05rvvye.js.map