module.exports=[34462,a=>{"use strict";var b=a.i(3171);a.s([],36618),a.i(36618),a.s(["0095ac9cd4abea72dc68d3fc1860812a8cd4cff00c",()=>b.logout],34462)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_pages_page_actions_05rvvye.js.map