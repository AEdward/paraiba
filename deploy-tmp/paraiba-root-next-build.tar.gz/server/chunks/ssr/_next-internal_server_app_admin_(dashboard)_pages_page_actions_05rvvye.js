module.exports=[34462,a=>{"use strict";var b=a.i(3171);a.s([],36618),a.i(36618),a.s(["004b39a86c76899ecef066e2ab7b6aae157aa75b29",()=>b.logout],34462)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_pages_page_actions_05rvvye.js.map