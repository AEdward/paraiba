module.exports=[34462,a=>{"use strict";var b=a.i(3171);a.s([],36618),a.i(36618),a.s(["0059a54d7b55e6338b6a2b396045f3b580b86ac07e",()=>b.logout],34462)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_pages_page_actions_05rvvye.js.map