module.exports=[74663,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_products_%5Bslug%5D_page_actions_10f05t1.js.map