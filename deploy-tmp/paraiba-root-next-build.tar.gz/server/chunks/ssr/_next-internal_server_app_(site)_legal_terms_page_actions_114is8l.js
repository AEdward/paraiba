module.exports=[33623,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_legal_terms_page_actions_114is8l.js.map