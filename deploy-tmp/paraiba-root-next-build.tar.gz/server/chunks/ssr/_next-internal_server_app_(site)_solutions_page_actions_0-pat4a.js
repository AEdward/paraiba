module.exports=[67402,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_solutions_page_actions_0-pat4a.js.map