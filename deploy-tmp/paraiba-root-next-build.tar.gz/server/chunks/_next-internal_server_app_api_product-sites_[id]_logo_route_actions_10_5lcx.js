module.exports=[58252,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_product-sites_%5Bid%5D_logo_route_actions_10_5lcx.js.map