module.exports=[144,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bid%5D_screenshot_route_actions_0tlzh8i.js.map