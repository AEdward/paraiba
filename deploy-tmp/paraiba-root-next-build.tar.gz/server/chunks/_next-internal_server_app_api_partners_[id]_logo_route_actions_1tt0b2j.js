module.exports=[68568,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_partners_%5Bid%5D_logo_route_actions_1tt0b2j.js.map