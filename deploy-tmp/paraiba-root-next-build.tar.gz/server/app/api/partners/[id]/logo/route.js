var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/partners/[id]/logo/route.js")
R.c("server/chunks/[root-of-the-server]__023rze0._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0kdmmuk._.js")
R.c("server/chunks/_next-internal_server_app_api_partners_[id]_logo_route_actions_1tt0b2j.js")
R.m(19152)
module.exports=R.m(19152).exports
