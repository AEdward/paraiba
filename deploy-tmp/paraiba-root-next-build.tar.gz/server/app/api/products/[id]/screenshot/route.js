var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/screenshot/route.js")
R.c("server/chunks/[root-of-the-server]__14f07n5._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0kdmmuk._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_screenshot_route_actions_0tlzh8i.js")
R.m(74405)
module.exports=R.m(74405).exports
