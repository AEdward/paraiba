var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/product-sites/[id]/logo/route.js")
R.c("server/chunks/[root-of-the-server]__1bdu0sn._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/src_01ch23q._.js")
R.c("server/chunks/_next-internal_server_app_api_product-sites_[id]_logo_route_actions_10_5lcx.js")
R.m(91693)
module.exports=R.m(91693).exports
