var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/documents/[id]/route.js")
R.c("server/chunks/[externals]__1a1arqa._.js")
R.c("server/chunks/src_01ch23q._.js")
R.c("server/chunks/node_modules_next_dist_11w3z5e._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_1te_6ks._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_documents_[id]_route_actions_1lbolpi.js")
R.m(5847)
module.exports=R.m(5847).exports
