var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__1bcl9-v._.js")
R.c("server/chunks/[root-of-the-server]__09k_q8k._.js")
R.m(89997)
module.exports=R.m(89997).exports
